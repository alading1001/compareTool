"""核对正式 EXE 的内嵌身份、应用模块和资源，不执行用户转换程序。"""
import hashlib
import json
import marshal
import subprocess
import sys
import types
from pathlib import Path
from PyInstaller.archive.readers import CArchiveReader

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.build_release import source_fingerprint


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def normalise(code):
    return code.replace(co_filename='<application>', co_consts=tuple(
        normalise(value) if isinstance(value, types.CodeType) else value
        for value in code.co_consts))


info = json.loads((ROOT / 'dist/CompareTool_build.json').read_text('utf-8'))
receipt = json.loads((ROOT / 'artifacts/permission-report-filter-compatibility-20261021.json').read_text('utf-8'))
assert info['source_sha256'] == source_fingerprint(ROOT) == receipt['runtime_source_sha256']
assert not info['dirty']
assert info['commit'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
assert info['exe_sha256'] == digest(ROOT / 'dist/CompareTool.exe')
archive = CArchiveReader(str(ROOT / 'dist/CompareTool.exe'))
embedded = json.loads(archive.extract('build_info.json'))
assert embedded == {k: v for k, v in info.items() if k != 'exe_sha256'}
pyz = archive.open_embedded_archive('PYZ.pyz')
modules = []
for path in sorted([*ROOT.glob('*.py'), *(ROOT / 'vcs').rglob('*.py')]):
    if '__pycache__' in path.parts:
        continue
    rel = path.relative_to(ROOT)
    name = '.'.join(rel.with_suffix('').parts)
    if name.endswith('.__init__'):
        name = name[:-9]
    packaged = marshal.loads(archive.extract('main')) if name == 'main' else pyz.extract(name)
    expected = compile(path.read_bytes(), str(path), 'exec', dont_inherit=True, optimize=0)
    assert normalise(packaged) == normalise(expected), name
    modules.append(name)
resources = []
for folder in ('templates', 'assets'):
    for path in sorted((ROOT / folder).rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        rel = path.relative_to(ROOT)
        assert archive.extract(str(rel)) == path.read_bytes(), str(rel)
        resources.append(rel.as_posix())
assert not any('summary_permissions.html' in name for name in archive.toc)
assert (ROOT / 'docs/CompareTool_使用说明书.pdf').read_bytes() == (ROOT / 'dist/CompareTool_使用说明书.pdf').read_bytes()
result = dict(build=info, embedded_metadata_identical=True,
              application_modules_identical=modules, resources_identical=resources,
              retired_template_absent=True, manual_identical=True,
              manual_sha256=digest(ROOT / 'docs/CompareTool_使用说明书.pdf'),
              verified_runtime_source_unchanged=True)
(WORK / 'package-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(version=info['version'], build_id=info['build_id'], clean_build=True,
                     modules=len(modules), resources=len(resources), manual_identical=True)))
