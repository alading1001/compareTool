"""只读盘点本轮复核现场和保护对象，不执行任何删除。"""
import hashlib
import json
import os
import stat
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
preflight = json.loads((WORK / 'preflight.json').read_text('utf-8'))


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


protected = []
for name, expected in preflight['protected'].items():
    path = Path(name)
    actual = digest(path)
    assert actual == expected, f'保护对象发生变化: {path.name}'
    protected.append(dict(category=('original_input' if path.suffix == '.tar' else
                                   'installed_bundle' if 'applications' in path.parts else 'user_config'),
                          name=path.name, sha256=actual, unchanged=True))
(WORK / 'protected-verification.json').write_text(json.dumps(protected, ensure_ascii=False, indent=2), encoding='utf-8')
names = ['permission_report_ui_20261021', 'report_filter_restore_20261021',
         'folder_permission_audit_20261021', 'release_closeout_20261022', 'release_build_l1tv9yde',
         *('archive_workflow_' + suffix for suffix in (
             '0sskmr47','33vnl9xo','6a95xpjc','8psindlu','e7pmdas3','jvxrjaq0','r36p4hpl','rstd6gvv'))]
objects = []
for name in names:
    path = ROOT / '.tmp' / name
    if not path.exists():
        continue
    assert path.resolve().is_relative_to(ROOT / '.tmp')
    files, byte_count, directories = 0, 0, 1
    tree = hashlib.sha256()
    for parent, dirs, children in os.walk(path, followlinks=False):
        dirs.sort()
        for entry in dirs:
            if (Path(parent) / entry).lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise RuntimeError('候选目录存在重解析点，停止盘点')
        directories += len(dirs)
        for child in sorted(children):
            item = Path(parent) / child
            if item.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise RuntimeError('候选文件存在重解析点，停止盘点')
            files += 1
            byte_count += item.stat().st_size
            # 本脚本会更新自身所在目录中的快照，摘要只对本次读取时点有效。
            tree.update(item.relative_to(path).as_posix().encode('utf-8') + b'\0')
            tree.update(bytes.fromhex(digest(item)))
    objects.append(dict(path='.tmp/' + name, files=files, directories=directories,
                        bytes=byte_count, snapshot_sha256=tree.hexdigest(),
                        state='retained-awaiting-post-report-confirmation',
                        reason=('本次发布的构建中间文件，正式三件套已独立保留' if name.startswith('release_build_') else
                                '本次功能验证、审计或发布的复核现场；必要证据另行归档')))
preview=dict(mode='read-only-preview', destructive_operations=0,
             retained_formal_outputs=['dist/CompareTool.exe','dist/CompareTool_build.json',
                                      'dist/CompareTool_使用说明书.pdf','dist/archive','artifacts'],
             retained_other_history=True, objects=objects,
             total_bytes=sum(row['bytes'] for row in objects))
(WORK / 'cleanup-preview.json').write_text(json.dumps(preview, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(protected_unchanged=len(protected), cleanup_candidates=len(objects),
                     retained_bytes=preview['total_bytes'], deleted=0), ensure_ascii=False))
