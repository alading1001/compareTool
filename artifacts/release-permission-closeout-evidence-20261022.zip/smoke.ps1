$ErrorActionPreference='Stop'
$projectRoot=(Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$smokeExe=Join-Path $projectRoot 'dist\CompareTool.exe'
$configPath=Join-Path $projectRoot 'dist\compareTool_config.json'
$existing=@(Get-Process CompareTool -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $smokeExe })
if ($existing.Count -ne 0) { throw '正式路径已有运行实例，未启动或改动它' }
$hadConfig=Test-Path -LiteralPath $configPath
$configBytes=if ($hadConfig) { [System.IO.File]::ReadAllBytes($configPath) } else { $null }
if ($hadConfig) { [System.IO.File]::WriteAllBytes((Join-Path $PSScriptRoot 'dist-config-before.json'),$configBytes) }
$expected=Get-Content -LiteralPath (Join-Path $projectRoot 'dist\CompareTool_build.json') -Raw | ConvertFrom-Json
$env:TEMP=Join-Path $PSScriptRoot 'os-temp'
$env:TMP=$env:TEMP
$env:COMPARETOOL_TEMP_DIR=Join-Path $PSScriptRoot 'runtime'
Add-Type -AssemblyName System.Drawing
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class CloseoutWindow {
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool GetExitCodeProcess(IntPtr process, out uint code);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int left,top,right,bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr window, out RECT rect);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr window, IntPtr dc, uint flags);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr window, StringBuilder name, int max);
    [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
}
'@
$started=Start-Process -FilePath $smokeExe -WorkingDirectory (Join-Path $projectRoot 'dist') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot 'smoke-stdout.log') -RedirectStandardError (Join-Path $PSScriptRoot 'smoke-stderr.log')
$processHandle=$started.Handle
$windowProcess=$null
try {
    for ($attempt=0; $attempt -lt 60; $attempt++) {
        foreach ($proc in @(Get-Process CompareTool -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $smokeExe })) {
            $proc.Refresh()
            if ($proc.MainWindowHandle -ne 0) {
                $class=[System.Text.StringBuilder]::new(256)
                [CloseoutWindow]::GetClassName($proc.MainWindowHandle,$class,256) | Out-Null
                if ($class.ToString() -eq 'TkTopLevel') { $windowProcess=$proc; break }
            }
        }
        if ($null -ne $windowProcess) { break }
        Start-Sleep -Milliseconds 500
    }
    if ($null -eq $windowProcess) { throw '新 EXE 30 秒内未生成 Tk 窗口' }
    $title=$windowProcess.MainWindowTitle
    if (-not $title.Contains($expected.version) -or -not $title.Contains($expected.build_id)) { throw "标题版本不符：$title" }
    $response=[IntPtr]::Zero
    $responding=[CloseoutWindow]::SendMessageTimeout($windowProcess.MainWindowHandle,0,[IntPtr]::Zero,[IntPtr]::Zero,2,3000,[ref]$response)
    if ($responding -eq [IntPtr]::Zero) { throw '窗口未响应' }
    $rect=New-Object CloseoutWindow+RECT
    [CloseoutWindow]::GetWindowRect($windowProcess.MainWindowHandle,[ref]$rect) | Out-Null
    $bitmap=[System.Drawing.Bitmap]::new($rect.right-$rect.left,$rect.bottom-$rect.top)
    $graphics=[System.Drawing.Graphics]::FromImage($bitmap)
    $dc=$graphics.GetHdc()
    try { $captured=[CloseoutWindow]::PrintWindow($windowProcess.MainWindowHandle,$dc,2) }
    finally { $graphics.ReleaseHdc($dc); $graphics.Dispose() }
    if (-not $captured) { throw '窗口截图失败' }
    $bitmap.Save((Join-Path $PSScriptRoot 'window.png'),[System.Drawing.Imaging.ImageFormat]::Png)
    $bitmap.Dispose()
    $evidence=[ordered]@{path=$smokeExe; version=$expected.version; build_id=$expected.build_id; title=$title; parent_pid=$started.Id; window_pid=$windowProcess.Id; window_class='TkTopLevel'; responsive=$true; screenshot='window.png'; window_size=@(($rect.right-$rect.left),($rect.bottom-$rect.top))}
    [CloseoutWindow]::PostMessage($windowProcess.MainWindowHandle,0x0010,[IntPtr]::Zero,[IntPtr]::Zero) | Out-Null
    if (-not $started.WaitForExit(10000)) { throw '关闭窗口后新 EXE 未正常退出' }
    $nativeExitCode=[uint32]0
    if (-not [CloseoutWindow]::GetExitCodeProcess($processHandle,[ref]$nativeExitCode)) { throw "无法读取进程退出码" }
    if ($nativeExitCode -ne 0) { throw "新 EXE 退出码 $nativeExitCode" }
    $evidence['normal_exit']=$true
    $evidence['exit_code']=$nativeExitCode
    if ($hadConfig) {
        [System.IO.File]::WriteAllBytes($configPath,$configBytes)
        $evidence['config_bytes_preserved']=([System.Convert]::ToBase64String([System.IO.File]::ReadAllBytes($configPath)) -eq [System.Convert]::ToBase64String($configBytes))
    } else { $evidence['config_created_by_smoke']=Test-Path -LiteralPath $configPath }
    $evidence | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'smoke-verification.json') -Encoding utf8
    $evidence | ConvertTo-Json -Depth 5
} finally {
    if (-not $started.HasExited) {
        if ($null -ne $windowProcess) { [CloseoutWindow]::PostMessage($windowProcess.MainWindowHandle,0x0010,[IntPtr]::Zero,[IntPtr]::Zero) | Out-Null }
        $started.WaitForExit(3000) | Out-Null
    }
    if ($started.HasExited -and $hadConfig) { [System.IO.File]::WriteAllBytes($configPath,$configBytes) }
}
