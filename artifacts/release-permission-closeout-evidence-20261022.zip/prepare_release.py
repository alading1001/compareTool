"""准备与正式 dist 字节一致的 GitHub 发行附件及中文说明。"""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
out = WORK / 'github-assets'
out.mkdir(exist_ok=True)
metadata = json.loads((ROOT / 'dist/CompareTool_build.json').read_text('utf-8'))
package = json.loads((WORK / 'package-verification.json').read_text('utf-8'))
smoke = json.loads((WORK / 'smoke-verification.json').read_text('utf-8-sig'))
assert metadata == package['build']
assert smoke['normal_exit'] and smoke['responsive'] and smoke['config_bytes_preserved']
assert smoke['version'] == metadata['version'] and smoke['build_id'] == metadata['build_id']
mapping = {'CompareTool.exe': 'CompareTool.exe', 'CompareTool_build.json': 'CompareTool_build.json',
           'CompareTool_User_Manual.pdf': 'CompareTool_使用说明书.pdf'}
hashes = {}
for name, source in mapping.items():
    shutil.copy2(ROOT / 'dist' / source, out / name)
    hashes[name] = hashlib.sha256((out / name).read_bytes()).hexdigest()
    assert (out / name).read_bytes() == (ROOT / 'dist' / source).read_bytes()
(out / 'SHA256SUMS.txt').write_text(''.join(f'{value}  {name}\n' for name, value in hashes.items()), encoding='utf-8')
hashes['SHA256SUMS.txt'] = hashlib.sha256((out / 'SHA256SUMS.txt').read_bytes()).hexdigest()
(WORK / 'release-assets.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
notes = f'''本版包含自上一份 GitHub Release 以来的累计修复，重点解决压缩包权限变化被当成内容修改的问题。

- 同路径、原始字节相同的压缩包成员，权限不同单独记为 P“仅权限”。P 有统计、文件树、筛选和新旧权限详情，不导出文件内容；M/F/R 叠加权限时保留原分类及权限提示。
- 报告沿用“全部＋各类型”，默认全部选中，移除额外的“内容/路径”快捷筛选。变更文件总数包含 P，修改数只统计内容修改。
- 包含按内容识别 ZIP/TAR/GZIP、普通 `.dat.gz`、包内递归明细，以及 Git/SVN 多版本文件级首尾端点和交付完整性修复。
- 同步 17 页中文说明书。文件夹模式比较相对路径和内容，Windows ACL 比较本次不增加；需核对归档 Unix 权限时直接选择原始压缩包。

验证结果：原始双 TAR 在默认排除并开启递归时为 4 个内容修改、2872 个仅权限变化，8 份新旧导出与原始成员字节一致。权限展示阶段完整回归覆盖 810 项，809 通过、1 项因 Windows 符号链接权限不足跳过；恢复原有筛选后 50 项相关回归通过，7 份浏览器报告各验证 64 种筛选组合。上述业务样包通过源码桌面工作线程验证；正式 EXE 核对了 29 个应用模块、23 项模板及资源，并通过真实窗口版本、响应和正常退出冒烟。

构建版本 `{metadata['version']} [{metadata['build_id']}]`，从干净提交 `{metadata['commit']}` 构建。EXE SHA-256：`{metadata['exe_sha256']}`。

下载 `CompareTool.exe`、`CompareTool_build.json` 和 `CompareTool_User_Manual.pdf` 配套使用；PDF 为中文内容。`SHA256SUMS.txt` 提供三份附件校验值。已有配置请自行保留，发行附件不包含用户配置或业务输入。
'''
(WORK / 'release-notes.md').write_text(notes, encoding='utf-8')
print(json.dumps(dict(tag='v'+metadata['version'], target=metadata['commit'], assets=hashes), ensure_ascii=False))
