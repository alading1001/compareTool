"""归档本轮收尾事实并更新唯一现役版本入口；不清理现场。"""
import hashlib
import json
import re
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent


def read(name):
    return json.loads((WORK / name).read_text('utf-8-sig'))


package = read('package-verification.json')
smoke = read('smoke-verification.json')
remote = read('github-verification.json')
protected = read('protected-verification.json')
preview = read('cleanup-preview.json')
processes = read('process-reference-scan.json')
precommit = read('precommit-check.json')
metadata = package['build']
assert remote['latest'] and remote['all_downloaded_bytes_verified']
assert smoke['normal_exit'] and smoke['exit_code'] == 0 and smoke['config_bytes_preserved']
assert all(row['unchanged'] for row in protected)
assert not processes['matches']
receipt = dict(
    schema_version=1, status='RELEASE_PUBLISHED_AND_VERIFIED_CLEANUP_PENDING',
    verified_at=datetime.now().astimezone().isoformat(),
    purpose='权限展示及筛选兼容收尾、中文提交推送、干净构建与 GitHub Release 更新；不增加 Windows ACL 比较',
    build=metadata,
    behavior=dict(default_all=True, filter_types=['A','M','F','D','R','P'],
                  extra_shortcut=False, windows_folder_acl_comparison=False,
                  permission_only_records_excluded_from_delivery=True),
    sample=dict(source_desktop_worker=True, defaults_and_recursive=True,
                content_modifications=4, permission_only=2872, display_total=2876,
                exported_files=8, exported_bytes_match_original_members=True,
                receipt='permission-report-filter-compatibility-20261021.json'),
    source_validation=dict(
        previous_full_regression=dict(tests=810, passed=809, skipped=1,
                                      skip_reason='Windows 创建测试符号链接缺少特权 WinError 1314',
                                      receipt='permission-report-ui-20261021.json'),
        final_filter_regression=dict(tests=50, failures=0, errors=0, browser_reports=7,
                                     filter_combinations_each=64,
                                     runtime_source_sha256=metadata['source_sha256']),
        verification_scope='完整回归属于权限展示阶段；筛选恢复后的最终运行源码与 50 项定向、实际样包和浏览器验收指纹一致。'),
    package_validation=dict(embedded_metadata_identical=True,
                            application_modules=len(package['application_modules_identical']),
                            resources=len(package['resources_identical']),
                            all_application_code_and_resources_identical=True,
                            real_formal_exe_window_responsive=True,
                            window_title=smoke['title'], normal_exit=True, exit_code=0,
                            source_and_dist_config_preserved=True,
                            formal_exe_business_sample_repeated=False),
    manual=precommit['manual'], github=remote,
    protected=protected,
    knowledge_surfaces=dict(code='verified-current', runtime='changed-and-verified',
                            docs='changed-and-verified', rules='changed-and-verified',
                            memory='out-of-scope: generated-read-only',
                            workspace='verified-current: cleanup preview retained'),
    pending=['用户完整汇报后的清场确认；本轮未执行删除'],
    out_of_scope=['Windows ACL 比较', '替换常用安装目录', '手工更新生成记忆'],
    warnings=['前轮回归有 1 项 Windows 符号链接特权跳过',
              '常用安装目录 EXE、构建信息和说明书仍不配套；本次使用 dist 正式三件套'],
    cleanup=dict(objects=len(preview['objects']), bytes_at_preview=preview['total_bytes'],
                 deleted=0, process_reference_scan=processes,
                 candidates=[row['path'] for row in preview['objects']],
                 full_preview='release-permission-closeout-evidence-20261022.zip:cleanup-preview.json'))
receipt_path = ROOT / 'artifacts/release-permission-closeout-20261022.json'
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')


def redact(text):
    text = re.sub(r'D:(?:\\+|/)AI(?:\\+|/)project(?:\\+|/)compareTool_myself', '<PROJECT>', text, flags=re.I)
    return re.sub(r'C:(?:\\+|/)Users(?:\\+|/)12939', '<USER_HOME>', text, flags=re.I)


evidence = ROOT / 'artifacts/release-permission-closeout-evidence-20261022.zip'
names = ['package-verification.json','smoke-verification.json','precommit-check.json',
         'protected-verification.json','cleanup-preview.json','process-reference-scan.json',
         'github-verification.json','github-published.json','release-assets.json','release-notes.md',
         'build.log','smoke-stdout.log','smoke-stderr.log','verify_package.py','smoke.ps1',
         'prepare_release.py','inventory_closeout.py','publish_evidence.py']
with zipfile.ZipFile(evidence, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('verification.json', receipt_path.read_bytes())
    for name in names:
        archive.writestr(name, redact((WORK / name).read_text('utf-8-sig')).encode('utf-8'))
    # 原窗口截图含用户配置，仅留本地；说明书渲染不含用户业务信息。
    for name in ('manual-contact.png','manual-03.png','manual-14.png'):
        archive.writestr(name,(WORK/name).read_bytes())
with zipfile.ZipFile(evidence) as archive:
    assert archive.testzip() is None
    assert json.loads(archive.read('verification.json')) == receipt

p = ROOT / 'README.md'
text = p.read_text('utf-8')
start = text.index('本轮 P 文件树、筛选兼容和 Windows 文件夹比较边界')
end = text.index('使用 `dist/CompareTool.exe`', start)
text = text[:start] + f'''当前项目交付入口为 **`{metadata['version']} [{metadata['build_id']}]`**，从干净源码提交 `{metadata['commit'][:7]}` 构建。P 仅权限变化已纳入统计、文件树、详情及“全部＋各类型”筛选；默认显示全部，移除额外快捷入口。原始双 TAR 的源码桌面工作线程验收仍为 4 个内容修改、2872 个仅权限（默认排除并开启递归），8 份导出与原成员字节一致；正式 EXE 的 29 个应用模块、23 项模板和资源与验收源码一致，真实窗口版本、响应、正常退出及配置字节保留已核对。本次未在正式 EXE 界面重跑业务样包。17 页说明书两份字节一致，结构与渲染检查通过。见 [本次发布凭证](artifacts/release-permission-closeout-20261022.json)。

GitHub 最新发行版已更新为 [v{metadata['version']}]({remote['url']})，发布配套 EXE、构建信息、中文 PDF 和 SHA-256 清单；发布后实际下载的四份附件均与本地字节一致，标签指向上述构建提交。历史分类修复及发布见 [前次验证](artifacts/archive-permission-classification-20261021.json) 和 [前次发布](artifacts/release-permission-closeout-20261021.json)。

常用安装目录未替换。2026-10-22 收尾盘点观察到其中 EXE 与旧的 `2026.10.21.4` dirty 构建相同，但构建信息仍为 `2026.10.21.1`，说明书也较旧，三件套不配套；请使用本次 `dist` 三件套或 GitHub 新发行附件。原包、配置及安装目录的 8 个保护对象均未变化。历史已批准清理见 [前次清场凭证](artifacts/cleanup-permission-closeout-20261021.json)；本轮 13 项临时复核现场仍保留，候选范围和快照见 [本轮证据包](artifacts/release-permission-closeout-evidence-20261022.zip)，须在完整汇报后确认才清场。Windows ACL 比较未增加，生成记忆只读。

''' + text[end:]
p.write_text(text, encoding='utf-8')
print(json.dumps(dict(receipt=receipt_path.name, evidence=evidence.name,
                     evidence_sha256=hashlib.sha256(evidence.read_bytes()).hexdigest(),
                     release=remote['url'], protected_unchanged=len(protected), cleanup_deleted=0), ensure_ascii=False))
