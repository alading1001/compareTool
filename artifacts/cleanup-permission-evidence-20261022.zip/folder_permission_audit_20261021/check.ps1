$ErrorActionPreference = 'Stop'
$taskOld = '<USER_HOME>\Desktop\20261021\110'
$taskNew = '<USER_HOME>\Desktop\20261021\111'
$taskEvidence = $PSScriptRoot
$taskIssues = [System.Collections.Generic.List[object]]::new()

function Read-TreePermissions([string]$Root) {
    $records = [System.Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
    $queue = [System.Collections.Generic.Stack[string]]::new()
    $queue.Push($Root)
    while ($queue.Count) {
        $path = $queue.Pop()
        $relative = if ($path -eq $Root) { '.' } else { $path.Substring($Root.Length + 1).Replace('\','/') }
        try {
            $item = Get-Item -LiteralPath $path -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                $taskIssues.Add([PSCustomObject]@{Root=$Root;Path=$relative;Error='链接或重解析点，未跟随'})
                continue
            }
            $acl = Get-Acl -LiteralPath $path
            $records.Add($relative,[PSCustomObject]@{
                Directory=[bool]$item.PSIsContainer
                Owner=$acl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value
                Group=$acl.GetGroup([System.Security.Principal.SecurityIdentifier]).Value
                Access=$acl.GetSecurityDescriptorSddlForm([System.Security.AccessControl.AccessControlSections]::Access)
                Protected=$acl.AreAccessRulesProtected
                Canonical=$acl.AreAccessRulesCanonical
                Attributes=[long]$item.Attributes
            })
            if ($item.PSIsContainer) {
                foreach ($child in (Get-ChildItem -LiteralPath $path -Force -ErrorAction Stop)) {
                    $queue.Push($child.FullName)
                }
            }
        } catch {
            $taskIssues.Add([PSCustomObject]@{Root=$Root;Path=$relative;Error=$_.Exception.Message})
        }
    }
    return ,$records
}

$taskBefore = Read-TreePermissions $taskOld
$taskAfter = Read-TreePermissions $taskNew
$taskDifferences = [System.Collections.Generic.List[object]]::new()
$taskAttributeDifferences = [System.Collections.Generic.List[object]]::new()
$taskOnlyOld = @($taskBefore.Keys | Where-Object { -not $taskAfter.ContainsKey($_) })
$taskOnlyNew = @($taskAfter.Keys | Where-Object { -not $taskBefore.ContainsKey($_) })
foreach ($path in $taskBefore.Keys) {
    if (-not $taskAfter.ContainsKey($path)) { continue }
    $before = $taskBefore[$path]
    $after = $taskAfter[$path]
    $changed = @('Directory','Owner','Group','Access','Protected','Canonical') | Where-Object { $before.$_ -cne $after.$_ }
    if ($changed) {
        $taskDifferences.Add([PSCustomObject]@{Path=$path;Fields=@($changed);Old=$before;New=$after})
    }
    if ($before.Attributes -ne $after.Attributes) {
        $taskAttributeDifferences.Add([PSCustomObject]@{Path=$path;Old=$before.Attributes;New=$after.Attributes})
    }
}
$taskResult = [PSCustomObject]@{
    CheckedAt=(Get-Date).ToString('o')
    OldRoot=$taskOld
    NewRoot=$taskNew
    OldFiles=@($taskBefore.Values | Where-Object { -not $_.Directory }).Count
    NewFiles=@($taskAfter.Values | Where-Object { -not $_.Directory }).Count
    OldDirectories=@($taskBefore.Values | Where-Object Directory).Count
    NewDirectories=@($taskAfter.Values | Where-Object Directory).Count
    OnlyOld=$taskOnlyOld
    OnlyNew=$taskOnlyNew
    PermissionDifferences=@($taskDifferences)
    AttributeDifferences=@($taskAttributeDifferences)
    Issues=@($taskIssues)
}
$taskResult | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath (Join-Path $taskEvidence 'result.json') -Encoding utf8
@{Old=$taskBefore;New=$taskAfter} | ConvertTo-Json -Depth 8 -Compress | Set-Content -LiteralPath (Join-Path $taskEvidence 'snapshots.json') -Encoding utf8
[PSCustomObject]@{
    OldFiles=$taskResult.OldFiles;NewFiles=$taskResult.NewFiles
    OldDirectories=$taskResult.OldDirectories;NewDirectories=$taskResult.NewDirectories
    OnlyOld=$taskOnlyOld.Count;OnlyNew=$taskOnlyNew.Count
    PermissionDifferences=$taskDifferences.Count;AttributeDifferences=$taskAttributeDifferences.Count
    Issues=$taskIssues.Count;Evidence=(Join-Path $taskEvidence 'result.json')
} | ConvertTo-Json
