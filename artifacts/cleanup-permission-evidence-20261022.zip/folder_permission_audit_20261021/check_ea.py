"""只读检查两个目录所有成员是否保存扩展属性，避免遗漏解压工具保留的 Unix 元数据。"""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path

kernel = ctypes.WinDLL('kernel32', use_last_error=True)
ntdll = ctypes.WinDLL('ntdll')
kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
kernel.CreateFileW.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.CloseHandle.restype = wintypes.BOOL
class IO_STATUS_BLOCK(ctypes.Structure):
    _fields_ = [('StatusOrPointer', ctypes.c_void_p), ('Information', ctypes.c_size_t)]
ntdll.NtQueryInformationFile.argtypes = [wintypes.HANDLE, ctypes.POINTER(IO_STATUS_BLOCK), ctypes.c_void_p, wintypes.ULONG, ctypes.c_int]
ntdll.NtQueryInformationFile.restype = wintypes.LONG

def ea_size(path):
    # 仅请求读取属性；共享读写删除，不修改成员或原包。
    handle = kernel.CreateFileW(str(path), 0x88, 7, None, 3, 0x02200000, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        state = IO_STATUS_BLOCK()
        size = wintypes.ULONG()
        status = ntdll.NtQueryInformationFile(handle, ctypes.byref(state), ctypes.byref(size), ctypes.sizeof(size), 7)
        if status < 0:
            raise OSError(f'NtQueryInformationFile status=0x{status & 0xffffffff:08x}')
        if state.Information != ctypes.sizeof(size):
            raise OSError(f'扩展属性信息长度异常: {state.Information}')
        return size.value
    finally:
        kernel.CloseHandle(handle)

result = []
for root in (Path(r'<USER_HOME>\Desktop\20261021\110'), Path(r'<USER_HOME>\Desktop\20261021\111')):
    queue = [root]
    files = directories = 0
    present = []
    errors = []
    while queue:
        path = queue.pop()
        name = '.' if path == root else path.relative_to(root).as_posix()
        try:
            state = path.lstat()
            if state.st_file_attributes & 0x400:
                raise OSError('未跟随重解析点')
            size = ea_size(path)
            if size:
                present.append(dict(path=name, bytes=size))
            if state.st_file_attributes & 0x10:
                directories += 1
                with os.scandir(path) as entries:
                    queue.extend(Path(entry.path) for entry in entries)
            else:
                files += 1
        except OSError as exc:
            errors.append(dict(path=name,error=str(exc)))
    result.append(dict(root=str(root),files=files,directories=directories,extended_attributes=present,errors=errors))
Path(__file__).with_name('extended-attributes.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([dict(root=r['root'],files=r['files'],directories=r['directories'],entries_with_ea=len(r['extended_attributes']),errors=len(r['errors'])) for r in result],ensure_ascii=False))
