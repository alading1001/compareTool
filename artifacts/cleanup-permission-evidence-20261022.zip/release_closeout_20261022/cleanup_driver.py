"""用户批准后的精确清理：先保全证据，删除由原生 PowerShell 按清单执行。"""
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path.cwd().resolve()
RECEIPT = ROOT / 'artifacts/cleanup-permission-closeout-20261022.json'
EVIDENCE = ROOT / 'artifacts/cleanup-permission-evidence-20261022.zip'
BASE = ROOT / '.tmp/release_closeout_20261022'
TARGETS = [
    '.tmp/permission_report_ui_20261021', '.tmp/report_filter_restore_20261021',
    '.tmp/folder_permission_audit_20261021', '.tmp/release_closeout_20261022',
    '.tmp/release_build_l1tv9yde', '.tmp/archive_workflow_0sskmr47',
    '.tmp/archive_workflow_33vnl9xo', '.tmp/archive_workflow_6a95xpjc',
    '.tmp/archive_workflow_8psindlu', '.tmp/archive_workflow_e7pmdas3',
    '.tmp/archive_workflow_jvxrjaq0', '.tmp/archive_workflow_r36p4hpl',
    '.tmp/archive_workflow_rstd6gvv',
]


def stamp():
    return datetime.now().astimezone().isoformat()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    s = path.lstat()
    assert not s.st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT, str(path)
    return dict(device=s.st_dev, inode=s.st_ino, created_ns=s.st_birthtime_ns)


def safe(path):
    assert path.resolve().is_relative_to(ROOT / '.tmp')
    assert path.parent == ROOT / '.tmp'
    for parent in (ROOT, ROOT / '.tmp', path):
        identity(parent)
    return identity(path)


def inventory(path):
    rows, dirs = [], []
    for parent, names, files in os.walk(path, followlinks=False):
        names.sort()
        dirs.append(Path(parent).relative_to(path).as_posix())
        for name in names:
            identity(Path(parent) / name)
        for name in sorted(files):
            item = Path(parent) / name
            ident = identity(item)
            rows.append(dict(path=item.relative_to(path).as_posix(), bytes=item.stat().st_size,
                             sha256=sha(item), identity=ident))
    tree = hashlib.sha256()
    for row in rows:
        tree.update(row['path'].encode('utf-8') + b'\0')
        tree.update(bytes.fromhex(row['sha256']))
    return dict(path=path.relative_to(ROOT).as_posix(), identity=safe(path), files=len(rows),
                directories=len(dirs), bytes=sum(r['bytes'] for r in rows),
                snapshot_sha256=tree.hexdigest(), members=rows, directory_paths=dirs)


def file_map():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    result = {p.decode('utf-8'): sha(ROOT / p.decode('utf-8')) for p in paths if p}
    for folder in ('dist', 'artifacts'):
        for parent, dirs, files in os.walk(ROOT / folder, followlinks=False):
            for name in dirs:
                identity(Path(parent) / name)
            for name in files:
                p = Path(parent) / name
                if p in (RECEIPT, EVIDENCE):
                    continue
                identity(p)
                result[p.relative_to(ROOT).as_posix()] = sha(p)
    for label, path in external_files().items():
        if path.exists():
            result[label] = sha(path)
    for name in ('compareTool_config.json',):
        p = ROOT / name
        if p.exists():
            result[name] = sha(p)
    return result


def external_files():
    originals = Path.home() / 'Desktop/20261021'
    installed = Path('D:/java/applications/CompareTool')
    return {
        **{'<ORIGINAL>/' + n: originals / n for n in ('110.tar', '111.tar')},
        **{'<INSTALLATION>/' + n: installed / n for n in
           ('CompareTool.exe','CompareTool_build.json','CompareTool_使用说明书.pdf','compareTool_config.json')},
    }


def siblings():
    target_names = {Path(x).name for x in TARGETS}
    return {p.name: dict(identity=identity(p), directory=p.is_dir(),
                         sha256=None if p.is_dir() else sha(p))
            for p in (ROOT / '.tmp').iterdir() if p.name not in target_names}


def process_scan():
    script = r'''$ErrorActionPreference='Stop'; @(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID } | Select-Object ProcessId,Name,ExecutablePath,CommandLine) | ConvertTo-Json -Depth 3 -Compress'''
    raw = subprocess.check_output(['powershell.exe','-NoProfile','-Command',script])
    records = json.loads(raw.decode('utf-8-sig'))
    matches = []
    for proc in records:
        if proc['ProcessId'] in (os.getpid(), os.getppid()):
            continue
        text = ((proc['ExecutablePath'] or '') + '\n' + (proc['CommandLine'] or '')).replace('\\','/').lower()
        for rel in TARGETS:
            if str(ROOT / rel).replace('\\','/').lower() in text:
                matches.append(dict(pid=proc['ProcessId'], name=proc['Name'], target=rel))
    assert not matches, matches
    return dict(active_target_references=matches,
                method='CIM executable path and command line; own verifier excluded',
                open_handle_enumeration=False)


def redact(text):
    text = re.sub(r'D:(?:\\+|/)AI(?:\\+|/)project(?:\\+|/)compareTool_myself','<PROJECT>',text,flags=re.I)
    return re.sub(r'C:(?:\\+|/)Users(?:\\+|/)12939','<USER_HOME>',text,flags=re.I)


def prepare():
    assert not RECEIPT.exists() and not EVIDENCE.exists(), '清理凭证已存在，不能覆盖旧记录'
    release = json.loads((ROOT / 'artifacts/release-permission-closeout-20261022.json').read_text('utf-8'))
    preview = json.loads((BASE / 'cleanup-preview.json').read_text('utf-8'))
    assert set(TARGETS) == set(release['cleanup']['candidates']) == {x['path'] for x in preview['objects']}
    assert not subprocess.check_output(['git','status','--porcelain'])
    processes = process_scan()
    manifests = []
    for rel in TARGETS:
        path = ROOT / rel
        safe(path)
        row = inventory(path)
        previous = next(x for x in preview['objects'] if x['path'] == rel)
        row['matches_preview_snapshot'] = row['snapshot_sha256'] == previous['snapshot_sha256']
        if rel != '.tmp/release_closeout_20261022':
            assert row['matches_preview_snapshot'], f'清单对象发生非预期变化：{rel}'
        manifests.append(row)
        print(json.dumps(dict(inventoried=rel, files=row['files'], bytes=row['bytes'])), flush=True)
    protected = file_map()
    other = siblings()
    state = dict(schema='comparetool.cleanup.v2', status='prepared', cleanup_performed=False,
                 prepared_at_beijing=stamp(),
                 authorization=dict(user_text='可以，把这13项临时现场清理掉，正式包和必要验证凭证保留。',
                                    post_report=True, exact_target_count=13, scope=TARGETS),
                 base_commit=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
                 targets=[{k:v for k,v in row.items() if k not in ('members','directory_paths')} for row in manifests],
                 protected_files=protected, unrelated_tmp_entries=other, process_check=processes,
                 preview_delta_note='发布收尾目录在预览后新增最终下载校验、远端终态及本次清理脚本；其余12项目录摘要与预览一致',
                 preserved_evidence=dict(path=EVIDENCE.relative_to(ROOT).as_posix()),
                 verification_boundary='仅删除已批准的13项临时目录；保留源代码、正式三件套、旧构建、原包、配置及历史凭证。')
    supplements = []
    for folder in ('permission_report_ui_20261021','report_filter_restore_20261021'):
        p = ROOT / '.tmp' / folder
        supplements.extend(x for x in p.glob('*.json') if not x.name.endswith('progress.json'))
    supplements += [ROOT / '.tmp/permission_report_ui_20261021/acceptance-v2/verification.json',
                    ROOT / '.tmp/folder_permission_audit_20261021/result.json',
                    ROOT / '.tmp/folder_permission_audit_20261021/extended-attributes.json',
                    ROOT / '.tmp/folder_permission_audit_20261021/check.ps1',
                    ROOT / '.tmp/folder_permission_audit_20261021/check_ea.py',
                    BASE / 'final-state.json', BASE / 'github-verification.json',
                    BASE / 'cleanup_driver.py', ROOT / '.tmp/release_build_l1tv9yde/build_info.json']
    with zipfile.ZipFile(EVIDENCE,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('preflight.json',json.dumps(state,ensure_ascii=False,indent=2))
        archive.writestr('target-manifests.json',json.dumps(manifests,ensure_ascii=False,indent=2))
        for p in supplements:
            assert p.exists(),p.name
            archive.writestr(p.relative_to(ROOT / '.tmp').as_posix(),redact(p.read_text('utf-8-sig')).encode('utf-8'))
    with zipfile.ZipFile(EVIDENCE) as archive:
        assert archive.testzip() is None
    state['preserved_evidence'].update(sha256=sha(EVIDENCE),bytes=EVIDENCE.stat().st_size,
                                      content='清理前清单、保护对象摘要、全量成员摘要、补存的浏览器/样包/权限审计及发布终态；不含业务正文或用户配置')
    RECEIPT.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(status='prepared',targets=13,files=sum(x['files'] for x in manifests),
                         bytes=sum(x['bytes'] for x in manifests),protected=len(protected),
                         evidence=state['preserved_evidence'])),flush=True)


def finish():
    state = json.loads(RECEIPT.read_text('utf-8'))
    assert state['status']=='prepared'
    assert all(not (ROOT / rel).exists() for rel in TARGETS)
    assert sha(EVIDENCE)==state['preserved_evidence']['sha256']
    assert file_map()==state['protected_files'], '保护对象发生变化'
    assert siblings()==state['unrelated_tmp_entries'], '清单外临时对象发生变化'
    with zipfile.ZipFile(EVIDENCE) as archive:
        assert archive.testzip() is None
    state.update(status='passed',cleanup_performed=True,verified_at_beijing=stamp(),
                 result=dict(deleted_targets=13,deleted_files=sum(x['files'] for x in state['targets']),
                             logical_bytes_removed=sum(x['bytes'] for x in state['targets']),
                             all_targets_absent=True,protected_hashes_unchanged=True,
                             unrelated_tmp_entries_unchanged=True,preserved_evidence_crc_valid=True))
    RECEIPT.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(status='passed',**state['result']),ensure_ascii=False))


if __name__=='__main__':
    if sys.argv[1:] == ['finish']:
        finish()
    else:
        prepare()
