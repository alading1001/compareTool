"""已确认清单的只读预检和清理后核验；删除由 PowerShell 固定清单执行。"""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import zipfile
from datetime import datetime

ROOT = Path.cwd().resolve()
assert str(ROOT).casefold() == 'D:/AI/project/compareTool_myself'.replace('/', os.sep).casefold()
RECEIPT = ROOT/'artifacts/cleanup-permission-closeout-20261021.json'
EVIDENCE = ROOT/'artifacts/cleanup-permission-evidence-20261021.zip'
PREVIEW = ROOT/'.tmp/permission-release-closeout-20261021/cleanup-preview.json'
REPARSE = getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def no_link(path):
    item = path.lstat()
    assert not stat.S_ISLNK(item.st_mode) and not getattr(item,'st_file_attributes',0)&REPARSE, str(path)
    return item


def snapshot(path):
    top = no_link(path)
    parts = []
    files = count_bytes = directories = 0
    pending = [path]
    while pending:
        item = pending.pop()
        current = no_link(item)
        rel = item.relative_to(path).as_posix() if item!=path else '.'
        if stat.S_ISDIR(current.st_mode):
            directories += 1
            parts.append((rel,'D',''))
            pending.extend(sorted(item.iterdir(),reverse=True))
        else:
            assert stat.S_ISREG(current.st_mode), str(item)
            files += 1
            count_bytes += current.st_size
            parts.append((rel,'F',str(current.st_size)+':'+sha(item)))
    digest = hashlib.sha256()
    for rel,kind,value in sorted(parts):
        for segment in (rel,kind,value):
            data = segment.encode('utf-8')
            digest.update(len(data).to_bytes(8,'big')+data)
    return {'path':path.relative_to(ROOT).as_posix(), 'is_directory':stat.S_ISDIR(top.st_mode),
            'files':files,'directories':directories,'bytes':count_bytes,'tree_sha256':digest.hexdigest(),
            'identity':{'device':top.st_dev,'inode':top.st_ino,'creation_ns':top.st_birthtime_ns}}


def sources():
    result = {}
    raw = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT)
    for rel in raw.decode('utf-8').split('\0'):
        if rel:
            result['tracked/'+rel] = ROOT/rel
    for base,label in [(ROOT/'dist','dist'),(Path('D:/java/applications/CompareTool'),'installation')]:
        for name in ('CompareTool.exe','CompareTool_build.json','CompareTool_使用说明书.pdf','compareTool_config.json'):
            if (base/name).is_file():
                result[label+'/'+name] = base/name
    for item in (ROOT/'dist/archive').rglob('*'):
        if item.is_file():
            no_link(item)
            result[item.relative_to(ROOT).as_posix()] = item
    for name in ('110.tar','111.tar'):
        item = Path.home()/'Desktop/20261021'/name
        assert item.is_file()
        result['source-input/'+name] = item
    for name in ('compareTool_config.json',):
        if (ROOT/name).is_file():
            result['project-local/'+name] = ROOT/name
    return result


def protected_state():
    return {label:{'sha256':sha(path),'bytes':path.stat().st_size} for label,path in sorted(sources().items())}


def other_entries(targets):
    target_names = {Path(item['path']).name for item in targets}
    return {p.name:{'device':s.st_dev,'inode':s.st_ino,'creation_ns':s.st_birthtime_ns,
                    'is_directory':stat.S_ISDIR(s.st_mode),
                    'sha256':sha(p) if stat.S_ISREG(s.st_mode) else None}
            for p in (ROOT/'.tmp').iterdir() if p.name not in target_names
            for s in (p.lstat(),)}


def process_check(processes, targets):
    for process in processes:
        data = (str(process.get('ExecutablePath') or '')+' '+str(process.get('CommandLine') or '')).casefold().replace('/','\\')
        for target in targets:
            full = str(ROOT/target['path']).casefold().replace('/','\\')
            assert full not in data, f"目标仍被进程 {process.get('ProcessId')} 引用：{target['path']}"


phase = sys.argv[1]
if phase == 'prepare':
    assert not RECEIPT.exists() and not EVIDENCE.exists(), 'Do not overwrite an existing cleanup receipt'
    assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
    preview = json.loads(PREVIEW.read_text(encoding='utf-8'))
    assert len(preview['candidates'])==24
    for ancestor in [ROOT,ROOT/'.tmp',*ROOT.parents]:
        no_link(ancestor)
    actual = []
    for item in preview['candidates']:
        path = ROOT/item['path']
        assert path.parent==ROOT/'.tmp' and path.resolve().parent==ROOT/'.tmp'
        current = snapshot(path)
        current['preview_files'] = item['files']
        current['preview_bytes'] = item['bytes']
        actual.append(current)
    processes = json.loads((PREVIEW.parent/'cleanup-process-before.json').read_text(encoding='utf-8-sig'))
    if isinstance(processes,dict):
        processes = [processes]
    process_check(processes,actual)
    preserved = protected_state()
    current_head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    receipt = {'schema':'comparetool.cleanup.v2','status':'prepared','cleanup_performed':False,
               'authorization':{'user_text':'清理','post_report':True,
                                'scope':'前一最终报告的24项临时对象，仅此清单',
                                'prior_final_commit':current_head},
               'prepared_at_beijing':datetime.now().astimezone().isoformat(timespec='seconds'),
               'targets':actual,'protected_before':preserved,'other_tmp_before':other_entries(actual),
               'process_check':{'active_target_processes':0,'unrelated_installed_exe_left_running':sum(p.get('Name')=='CompareTool.exe' for p in processes)},
               'preview_delta_note':'收尾目录在预览后新增最终凭证、核验记录和本次清理核验脚本，均为本会话产物；清理目标仍为同24项'}
    with zipfile.ZipFile(EVIDENCE,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.write(PREVIEW,'cleanup/approved-preview.json')
        for relative,label in [('.tmp/permission-fix-validation-20261021-e0bc1a89/full.log','regression/full.log'),
                               ('.tmp/permission-fix-validation-20261021-0de76d68/reports.log','regression/final-reports.log'),
                               ('.tmp/permission-fix-validation-20261021-8980c182/focused.log','regression/initial-focused.log')]:
            path = ROOT/relative
            if not path.is_file():
                continue
            raw = path.read_bytes()
            text = raw.decode('utf-16') if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else raw.decode('utf-8-sig')
            for private,alias in [(str(ROOT),'<project>'),(str(Path.home()),'<user-profile>')]:
                text = text.replace(private,alias).replace(private.replace('\\','/'),alias)
            archive.writestr(label,text.encode('utf-8'))
        for name in ('cleanup_prepare.py','cleanup_apply.ps1','final-verification.json','doc-link-check.json','source-parity.json'):
            path = PREVIEW.parent/name
            if path.is_file():
                archive.write(path,'cleanup/'+name)
        archive.write(ROOT/'artifacts/archive-permission-classification-20261021.json','source/source-acceptance.json')
        archive.write(ROOT/'artifacts/release-permission-closeout-20261021.json','release/release-receipt-before-cleanup.json')
    with zipfile.ZipFile(EVIDENCE) as archive:
        assert archive.testzip() is None
    receipt['preserved_evidence'] = {'path':EVIDENCE.relative_to(ROOT).as_posix(),'bytes':EVIDENCE.stat().st_size,
                                     'sha256':sha(EVIDENCE),'contents':'完整回归及最终相关回归日志、批准清单、源码验收、最终发布核验及清理脚本；不含业务正文或用户配置'}
    dump(RECEIPT,receipt)
    print(json.dumps({'status':'prepared','targets':len(actual),'files':sum(x['files'] for x in actual),
                      'bytes':sum(x['bytes'] for x in actual),'protected_files':len(preserved),
                      'no_target_processes':True,'evidence_bytes':EVIDENCE.stat().st_size},ensure_ascii=False))
elif phase == 'check':
    receipt = json.loads(RECEIPT.read_text(encoding='utf-8'))
    assert receipt['status']=='prepared'
    for old in receipt['targets']:
        current = snapshot(ROOT/old['path'])
        for key in ('files','directories','bytes','tree_sha256','identity','is_directory'):
            assert current[key]==old[key], (old['path'],key)
    assert protected_state()==receipt['protected_before']
    assert other_entries(receipt['targets'])==receipt['other_tmp_before']
    print('Pre-delete target identities, tree hashes, protected files and unrelated entries match.')
elif phase == 'verify':
    receipt = json.loads(RECEIPT.read_text(encoding='utf-8'))
    assert all(not (ROOT/item['path']).exists() for item in receipt['targets'])
    assert protected_state()==receipt['protected_before'], 'Protected files changed'
    assert other_entries(receipt['targets'])==receipt['other_tmp_before'], 'Unrelated .tmp entries changed'
    receipt['status'] = 'passed'
    receipt['cleanup_performed'] = True
    receipt['verified_at_beijing'] = datetime.now().astimezone().isoformat(timespec='seconds')
    receipt['result'] = {'deleted_targets':len(receipt['targets']),
                         'deleted_files':sum(x['files'] for x in receipt['targets']),
                         'logical_bytes_removed':sum(x['bytes'] for x in receipt['targets']),
                         'all_targets_absent':True,'protected_hashes_unchanged':True,
                         'unrelated_tmp_entries_unchanged':True}
    receipt['verification_boundary'] = '清理24项临时对象；不改变应用代码或重新构建，不扩大此前测试和EXE验收范围'
    dump(RECEIPT,receipt)
    print(json.dumps(receipt['result'],ensure_ascii=False))
else:
    raise RuntimeError(phase)
