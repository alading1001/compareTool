$ErrorActionPreference='Stop'
$cleanupRoot='D:\AI\project\compareTool_myself'
$cleanupTmp=Join-Path $cleanupRoot '.tmp'
$receiptPath=Join-Path $cleanupRoot 'artifacts\cleanup-permission-closeout-20261021.json'
$receipt=Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
if ($receipt.status -ne 'prepared' -or $receipt.targets.Count -ne 24 -or $receipt.authorization.user_text -ne '清理' -or -not $receipt.authorization.post_report) { throw '清理授权或清单状态不符' }
$resolvedRoot=(Resolve-Path -LiteralPath $cleanupRoot).Path
$resolvedTmp=(Resolve-Path -LiteralPath $cleanupTmp).Path
if ($resolvedRoot -ne $cleanupRoot -or $resolvedTmp -ne $cleanupTmp) { throw '工作区路径不符' }
$checkedTargets=@()
foreach ($target in $receipt.targets) {
    $candidate=[IO.Path]::GetFullPath((Join-Path $cleanupRoot $target.path))
    if ([IO.Path]::GetDirectoryName($candidate) -ne $resolvedTmp) { throw "目标超出清单目录：$candidate" }
    $resolved=(Resolve-Path -LiteralPath $candidate).Path
    if ($resolved -ne $candidate) { throw "目标解析路径变化：$candidate" }
    $item=Get-Item -LiteralPath $resolved -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "拒绝重解析目标：$resolved" }
    if ([bool]$item.PSIsContainer -ne [bool]$target.is_directory) { throw "目标类型变化：$resolved" }
    if ($item.PSIsContainer) {
        $links=@(Get-ChildItem -LiteralPath $resolved -Recurse -Force | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 })
        if ($links.Count) { throw "目标中存在链接：$resolved" }
    }
    $checkedTargets += $resolved
}
$processes=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(CompareTool|python|pythonw|git|svn|pyinstaller)(\.exe)?$' })
foreach ($process in $processes) {
    $processData=[string]$process.ExecutablePath+' '+[string]$process.CommandLine
    foreach ($target in $checkedTargets) {
        if ($processData.IndexOf($target,[StringComparison]::OrdinalIgnoreCase) -ge 0) { throw "目标仍有进程引用：$target" }
    }
}
foreach ($target in $checkedTargets) {
    # 所有绝对目标均已核对为本项目 .tmp 的直接子项；只删除批准清单。
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
}
foreach ($target in $checkedTargets) {
    if (Test-Path -LiteralPath $target) { throw "清理后目标仍存在：$target" }
}
Write-Output "已删除固定清单的 $($checkedTargets.Count) 项临时对象。"
