import gzip, hashlib, io, json, shutil, zipfile
from pathlib import Path
work = Path(__file__).resolve().parent
root = work.parents[1]
app = work/'packaged-smoke'
app.mkdir(exist_ok=True)
samples = work/'samples'
def archive(files):
    out = io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in files.items(): z.writestr(name,data)
    return out.getvalue()
tasks=[]
expected={}
for kind, project in [('archive','RenamedZip'),('archive','OdsGzip'),('folder','FolderText')]:
    paths=[]
    for side,word in [('old','BEFORE_RELEASE'),('new','AFTER_RELEASE')]:
        base=samples/project/side
        base.mkdir(parents=True,exist_ok=True)
        data=word.encode()+b'\n'
        if project=='RenamedZip':
            payload=archive({'T.dat.gz':gzip.compress(data,mtime=0),'aaa.tar.gz':data})
            path=base/'renamed-package'
            path.write_bytes(payload)
            export={'T.dat.gz':gzip.compress(data,mtime=0),'aaa.tar.gz':data}
        elif project=='OdsGzip':
            path=base/'T.dat.gz'
            path.write_bytes(gzip.compress(data,mtime=0))
            export={'T.dat':data}
        else:
            path=base
            export={'aaa.tar.gz':data,'renamed-package':archive({'data.txt':data})}
            for name,value in export.items(): (base/name).write_bytes(value)
        paths.append(str(path))
        for name,value in export.items(): expected[f'{side}Version/{project}/{name}']=hashlib.sha256(value).hexdigest()
    tasks.append(dict(vcs_type=kind,project_name=project,project_path='',old_version=paths[0],new_version=paths[1],exclude_rules='',show_project_root=True,show_full_context=True,recursive_archives=True,ignore_archive_root=False))
config=dict(vcs_type='archive',output_dir=str(work/'gui-output'),multi_tasks=tasks,
    last_comparison_paths={'archive':{'old_version':tasks[0]['old_version'],'new_version':tasks[0]['new_version']}},
    project_display_options={tasks[0]['new_version']:{'recursive_archives':True,'ignore_archive_root':False,'show_full_context':True,'show_project_root':True}})
(app/'compareTool_config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
(work/'smoke-expected.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')
print(json.dumps({'smoke':str(app),'tasks':len(tasks),'export_files':len(expected)}))
