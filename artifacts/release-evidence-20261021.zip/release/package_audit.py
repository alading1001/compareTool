import hashlib, importlib.abc, importlib.util, json, marshal, os, sys, types, unittest
from pathlib import Path
from PyInstaller.archive.readers import CArchiveReader
work = Path(__file__).resolve().parent
root = work.parents[1]
archive = CArchiveReader(str(root/'dist/CompareTool.exe'))
pyz = archive.open_embedded_archive(next(n for n,v in archive.toc.items() if v[-1]=='z'))
def normalize(code):
    return code.replace(co_filename='<source>',co_consts=tuple(normalize(c) if isinstance(c,types.CodeType) else c for c in code.co_consts))
codes={}
for path in sorted([*root.glob('*.py'),*(root/'vcs').glob('*.py')]):
    rel=path.relative_to(root).as_posix()
    name=rel[:-3].replace('/','.')
    if name.endswith('.__init__'): name=name[:-9]
    code=marshal.loads(archive.extract('main')) if name=='main' else pyz.extract(name)
    assert isinstance(code,types.CodeType),name
    assert normalize(code)==normalize(compile(path.read_bytes(),str(path),'exec',optimize=0)),name
    codes[name]=code
assets=[]
for folder in ('templates','assets'):
    for path in sorted((root/folder).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            rel=path.relative_to(root).as_posix()
            assert archive.extract(rel.replace('/','\\'))==path.read_bytes(),rel
            assets.append(rel)
metadata=json.loads(archive.extract('build_info.json'))
external=json.loads((root/'dist/CompareTool_build.json').read_text(encoding='utf-8'))
assert all(external[k]==v for k,v in metadata.items())
assert external['exe_sha256']==hashlib.sha256((root/'dist/CompareTool.exe').read_bytes()).hexdigest()
assert external['dirty'] is False
class PackagedLoader(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def find_spec(self,name,path=None,target=None):
        if name in codes: return importlib.util.spec_from_loader(name,self,is_package=name=='vcs')
    def create_module(self,spec): return None
    def exec_module(self,module):
        rel=module.__name__.replace('.','/')+('/__init__.py' if module.__name__=='vcs' else '.py')
        module.__file__=str(root/rel)
        exec(codes[module.__name__],module.__dict__)
sys.meta_path.insert(0,PackagedLoader())
sys.path[:0]=[str(root/'tests'),str(root)]
os.environ['TEMP']=os.environ['TMP']=os.environ['COMPARETOOL_TEMP_DIR']=str(work/'package-test-temp')
Path(os.environ['TEMP']).mkdir(exist_ok=True)
suite=unittest.TestLoader().loadTestsFromNames(['test_archive_content_detection','test_recent_project_name_persistence','test_archive_report_configuration.ArchiveConfigurationTests.test_source_browsers_start_from_remembered_directory'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
receipt={'code_modules_compared':len(codes),'modules':list(codes),'resource_files_compared':len(assets),'resources':assets,'metadata':external,'packaged_code_tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'loaded_packaged_modules':[n for n in codes if n in sys.modules]}
(work/'package-audit.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
assert result.wasSuccessful(),receipt
print(json.dumps(receipt,ensure_ascii=False))
