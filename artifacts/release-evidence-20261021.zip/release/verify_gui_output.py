import hashlib,json,re
from pathlib import Path
work=Path(__file__).resolve().parent
expected=json.loads((work/'smoke-expected.json').read_text())
output=work/'gui-output/20261021/multi_run_20261021_104557_923_868fa219'
actual={p.relative_to(output).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for side in ('oldVersion','newVersion') for p in (output/side).rglob('*') if p.is_file()}
assert actual==expected, (actual,expected)
report=next(output.glob('multi_compare_report_*.html'))
html=report.read_text(encoding='utf-8')
for token in ('RenamedZip','OdsGzip','FolderText','BEFORE_RELEASE','AFTER_RELEASE','T.dat','data.txt'): assert token in html,token
plain_templates=re.findall(r'<template class="diff-source"[^>]*data-path="aaa\.tar\.gz"[^>]*>(.*?)</template>',html,re.S)
assert len(plain_templates)==2,len(plain_templates)
for body in plain_templates:
    assert 'BEFORE_RELEASE' in body and 'AFTER_RELEASE' in body
    assert 'archive-original' not in body and '未展开' not in body
assert html.count('<details class="archive-original">')==2
assert all(token not in html for token in ('解析失败','未完成项','未展开原因'))
instructions=(output/'上线操作说明.txt').read_text(encoding='utf-8-sig')
assert '交付状态：已导出。' in instructions
assert '删除文件：0 个' in instructions and '重命名文件：0 个' in instructions
assert '新增和修改文件不在此重复列出' in instructions
info={'status':'passed','version':'2026.10.21.1','build_id':'e9dd517f30','actual_exe':str(work/'packaged-smoke/CompareTool.exe'),
 'visual_and_business_flow_verified':True,'picker':{'default_filter_observed':'所有文件 (*.*)','extensionless_package_visible_and_selected':True,'file':'samples/RenamedZip/old/renamed-package'},
 'multi_project_business_flow':{'projects':3,'changed_files':5,'completion_dialog_observed':True,'output':str(output),'original_export_files':len(actual),'byte_exact':True,'export_hashes':actual,'fake_suffix_text_diffs':len(plain_templates),'nested_archive_details':2,'partial_delivery':False},
 'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'source_of_assertions':'Actual native UI observations plus exported bytes and rendered HTML; no source worker substitution',
 'package_identity_dialog_observed':True}
(work/'gui-smoke.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(info,ensure_ascii=False))
