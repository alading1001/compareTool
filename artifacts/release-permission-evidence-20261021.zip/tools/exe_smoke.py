import ctypes
from ctypes import wintypes as wt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
EXE = ROOT/'dist/CompareTool.exe'
CONFIG = EXE.parent/'compareTool_config.json'
backup = CONFIG.read_bytes() if CONFIG.is_file() else None
if backup is not None:
    (WORK/'dist-config-before-smoke.json').write_bytes(backup)
meta = json.loads((EXE.parent/'CompareTool_build.json').read_text())
expected = '代码比对报告工具 v'+meta['version']+' ['+meta['build_id']+']'
u = ctypes.WinDLL('user32',use_last_error=True)
k = ctypes.WinDLL('kernel32',use_last_error=True)
cbtype = ctypes.WINFUNCTYPE(wt.BOOL,wt.HWND,wt.LPARAM)
u.EnumWindows.argtypes = (cbtype,wt.LPARAM)
u.EnumWindows.restype = wt.BOOL
u.GetWindowThreadProcessId.argtypes = (wt.HWND,ctypes.POINTER(wt.DWORD))
u.GetWindowTextW.argtypes = (wt.HWND,wt.LPWSTR,ctypes.c_int)
u.IsWindowVisible.argtypes = (wt.HWND,)
u.IsHungAppWindow.argtypes = (wt.HWND,)
u.PostMessageW.argtypes = (wt.HWND,wt.UINT,wt.WPARAM,wt.LPARAM)
u.SendMessageTimeoutW.argtypes = (wt.HWND,wt.UINT,wt.WPARAM,wt.LPARAM,wt.UINT,wt.UINT,ctypes.POINTER(ctypes.c_size_t))
u.SendMessageTimeoutW.restype = ctypes.c_ssize_t
k.OpenProcess.argtypes = (wt.DWORD,wt.BOOL,wt.DWORD)
k.OpenProcess.restype = wt.HANDLE
k.QueryFullProcessImageNameW.argtypes = (wt.HANDLE,wt.DWORD,wt.LPWSTR,ctypes.POINTER(wt.DWORD))
k.CloseHandle.argtypes = (wt.HANDLE,)


def windows():
    rows = []
    @cbtype
    def callback(hwnd, _):
        title = ctypes.create_unicode_buffer(2048)
        u.GetWindowTextW(hwnd,title,len(title))
        if title.value==expected:
            pid = wt.DWORD()
            u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
            handle = k.OpenProcess(0x1000,False,pid.value)
            path = ctypes.create_unicode_buffer(32768)
            length = wt.DWORD(len(path))
            try:
                if handle and k.QueryFullProcessImageNameW(handle,0,path,ctypes.byref(length)):
                    rows.append({'hwnd':int(hwnd),'pid':pid.value,'title':title.value,'exe':path.value,
                                 'visible':bool(u.IsWindowVisible(hwnd)), 'hung':bool(u.IsHungAppWindow(hwnd))})
            finally:
                if handle:
                    k.CloseHandle(handle)
        return True
    assert u.EnumWindows(callback,0)
    return rows


assert not windows(), 'Existing window with same new build identity; refusing to touch it'
env = os.environ.copy()
env['TEMP'] = env['TMP'] = str(WORK/'exe-runtime-temp')
Path(env['TEMP']).mkdir(exist_ok=True)
receipt = {'expected_title':expected,'actual_exe':str(EXE),'business_report_generation_in_exe':False}
with (WORK/'exe-stdout.log').open('wb') as out, (WORK/'exe-stderr.log').open('wb') as err:
    proc = subprocess.Popen([str(EXE)],cwd=EXE.parent,env=env,stdout=out,stderr=err,creationflags=0x08000000)
    receipt['launcher_pid'] = proc.pid
    target = None
    try:
        deadline = time.monotonic()+45
        while time.monotonic()<deadline:
            rows = windows()
            if rows:
                assert len(rows)==1, rows
                target = rows[0]
                assert Path(target['exe']).samefile(EXE), target
                break
            if proc.poll() is not None:
                raise RuntimeError('EXE exited before the main window appeared: '+str(proc.returncode))
            time.sleep(0.3)
        assert target, 'Main window did not appear'
        receipt['window'] = target
        answer = ctypes.c_size_t()
        receipt['responsive'] = bool(u.SendMessageTimeoutW(target['hwnd'],0,0,0,2,3000,ctypes.byref(answer)))
        assert target['visible'] and not target['hung'] and receipt['responsive'], target
        assert u.PostMessageW(target['hwnd'],0x0010,0,0)
        receipt['normal_exit_code'] = proc.wait(timeout=25)
        assert receipt['normal_exit_code']==0
        after = CONFIG.read_bytes() if CONFIG.is_file() else None
        receipt['config_changed_on_normal_exit'] = after!=backup
        if after!=backup and backup is not None:
            before_obj,after_obj = json.loads(backup),json.loads(after)
            receipt['config_changed_top_keys'] = [key for key in before_obj.keys()|after_obj.keys() if before_obj.get(key)!=after_obj.get(key)]
            CONFIG.write_bytes(backup)
        elif backup is None and after is not None:
            raise RuntimeError('Smoke created a new configuration; preserve for review')
        receipt['original_config_bytes_preserved'] = (CONFIG.read_bytes() if CONFIG.is_file() else None)==backup
        assert receipt['original_config_bytes_preserved']
        receipt['status'] = 'passed'
    finally:
        receipt['process_exited'] = proc.poll() is not None
        (WORK/'exe-smoke.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
